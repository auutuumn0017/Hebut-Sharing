import random
import time
import matplotlib.pyplot as plt

def generate_points(n):
    return [(random.uniform(1, 10), random.uniform(1, 10)) for _ in range(n)]

def distance(p1, p2):
    return ((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)**0.5

class BruteForceSolver:
    def __init__(self, points):
        self.points = points

    def solve(self):
        min_dist = float('inf')
        pair = None
        n = len(self.points)
        for i in range(n):
            for j in range(i + 1, n):
                dist = distance(self.points[i], self.points[j])
                if dist < min_dist:
                    min_dist = dist
                    pair = (self.points[i], self.points[j])
        return (min_dist, pair)

class DivideConquerSolver:
    def __init__(self, points):
        self.points = points

    def closest_pair_recursive(self, points_sorted):
        n = len(points_sorted)
        if n <= 3:
            return BruteForceSolver(points_sorted).solve()
        
        mid = n // 2
        left = points_sorted[:mid]
        right = points_sorted[mid:]
        
        d_left, pair_left = self.closest_pair_recursive(left)
        d_right, pair_right = self.closest_pair_recursive(right)
        
        d, pair = (d_left, pair_left) if d_left < d_right else (d_right, pair_right)
        
        mid_x = points_sorted[mid][0]
        strip = [p for p in points_sorted if abs(p[0] - mid_x) < d]
        strip_sorted = sorted(strip, key=lambda x: x[1]) # 按y坐标排序
        
        min_strip = d
        strip_pair = pair
        for i in range(len(strip_sorted)):
            for j in range(i + 1, min(i + 7, len(strip_sorted))):
                current_dist = distance(strip_sorted[i], strip_sorted[j])
                if current_dist < min_strip:
                    min_strip = current_dist
                    strip_pair = (strip_sorted[i], strip_sorted[j])
        
        if min_strip < d:
            return (min_strip, strip_pair)
        else:
            return (d, pair)

    def solve(self):
        points_sorted = sorted(self.points, key=lambda x: x[0])
        return self.closest_pair_recursive(points_sorted)

def main():
    # 不同数据规模
    sizes = [10, 50, 100, 200, 300, 400, 500]
    times_bf = []
    times_dc = []

    # 多次运行求平均时间
    num_runs = 5
    for size in sizes:
        total_time_bf = 0
        total_time_dc = 0
        for _ in range(num_runs):
            points = generate_points(size)
            
            # 蛮力法测试
            start_bf = time.time()
            bf_solver = BruteForceSolver(points)
            min_dist_bf, pair_bf = bf_solver.solve()
            total_time_bf += time.time() - start_bf
            
            # 分治法测试
            start_dc = time.time()
            dc_solver = DivideConquerSolver(points)
            min_dist_dc, pair_dc = dc_solver.solve()
            total_time_dc += time.time() - start_dc
        
        avg_time_bf = total_time_bf / num_runs
        avg_time_dc = total_time_dc / num_runs
        
        times_bf.append(avg_time_bf)
        times_dc.append(avg_time_dc)

    # 生成30个随机点
    points = generate_points(30)

    # 蛮力法测试
    start_bf = time.time()
    bf_solver = BruteForceSolver(points)
    min_dist_bf, pair_bf = bf_solver.solve()
    time_bf = time.time() - start_bf

    # 分治法测试
    start_dc = time.time()
    dc_solver = DivideConquerSolver(points)
    min_dist_dc, pair_dc = dc_solver.solve()
    time_dc = time.time() - start_dc

    # 输出结果
    print("Brute Force Method:")
    print(f"Closest pair: {pair_bf[0]}, {pair_bf[1]}")
    print(f"Distance: {min_dist_bf:.6f}")
    print(f"Time taken: {time_bf:.10f} seconds\n")

    print("Divide and Conquer Method:")
    print(f"Closest pair: {pair_dc[0]}, {pair_dc[1]}")
    print(f"Distance: {min_dist_dc:.6f}")
    print(f"Time taken: {time_dc:.10f} seconds\n")

    # 验证结果一致性
    assert abs(min_dist_bf - min_dist_dc) < 1e-6, "Results from two methods do not match!"

    # 创建一个包含两个子图的画布
    fig, axes = plt.subplots(1, 2, figsize=(20, 6))

    # 绘制收敛速度图
    axes[0].plot(sizes, times_bf, label='Brute Force', marker='o')
    axes[0].plot(sizes, times_dc, label='Divide and Conquer', marker='s')
    axes[0].set_xlabel('Number of Points')
    axes[0].set_ylabel('Average Time (seconds)')
    axes[0].set_title('Convergence Speed Comparison of Brute Force and Divide and Conquer')
    axes[0].legend()
    axes[0].grid(True)

    # 绘制最近点对结果图
    x_all = [p[0] for p in points]
    y_all = [p[1] for p in points]
    axes[1].scatter(x_all, y_all, color='blue', label='Points')

    # 绘制最近点对
    p1, p2 = pair_bf
    axes[1].plot([p1[0], p2[0]], [p1[1], p2[1]], 
             color='red', linestyle='--', linewidth=2, 
             marker='o', markersize=5, label='Closest Pair')

    axes[1].set_xlabel('X Coordinate')
    axes[1].set_ylabel('Y Coordinate')
    axes[1].set_title('Closest Pair of Points Visualization')
    axes[1].legend()
    axes[1].grid(True)

    plt.show()

if __name__ == '__main__':
    main()