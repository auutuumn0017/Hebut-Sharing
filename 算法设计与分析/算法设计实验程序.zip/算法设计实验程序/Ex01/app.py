from flask import Flask, jsonify, render_template, request
import random
import time
from Ex01_Nearest_point_pair import BruteForceSolver, DivideConquerSolver, generate_points

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/generate-points', methods=['POST'])
def generate_points_api():
    n = int(request.json['n'])
    points = generate_points(n)
    return jsonify({'points': points})

@app.route('/api/brute-force', methods=['POST'])
def brute_force_api():
    points = request.json['points']
    start = time.time()
    min_dist, pair = BruteForceSolver(points).solve()
    return jsonify({
        'time': time.time() - start,
        'distance': min_dist,
        'pair': pair
    })

@app.route('/api/divide-conquer', methods=['POST'])
def divide_conquer_api():
    points = request.json['points']
    start = time.time()
    min_dist, pair = DivideConquerSolver(points).solve()
    return jsonify({
        'time': time.time() - start,
        'distance': min_dist,
        'pair': pair
    })

if __name__ == '__main__':
    app.run(debug=True)