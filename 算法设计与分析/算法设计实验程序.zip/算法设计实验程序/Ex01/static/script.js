let chart = null;
let currentPoints = [];

function generatePoints() {
    const n = document.getElementById('pointCount').value;
    fetch('/api/generate-points', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({n: n})
    })
    .then(r => r.json())
    .then(data => {
        currentPoints = data.points;
        updateChart();
    });
}

function updateChart(pair) {
    const ctx = document.getElementById('pointChart').getContext('2d');
    
    if (chart) chart.destroy();
    
    chart = new Chart(ctx, {
        type: 'scatter',
        data: {
            datasets: [{
                label: '随机点',
                data: currentPoints.map(p => ({x: p[0], y: p[1]})),
                backgroundColor: 'rgba(54, 162, 235, 0.8)',
                pointRadius: 5
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {type: 'linear', min: 0, max: 11},
                y: {type: 'linear', min: 0, max: 11}
            }
        }
    });
}

function runBruteForce() {
    fetch('/api/brute-force', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({points: currentPoints})
    })
    .then(r => r.json())
    .then(showResult('蛮力法'));
}

function runDivideConquer() {
    fetch('/api/divide-conquer', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({points: currentPoints})
    })
    .then(r => r.json())
    .then(showResult('分治法'));
}

function showResult(algorithm) {
    return data => {
        const resultDiv = document.getElementById('resultDetails');
        resultDiv.innerHTML = `
            <h3>${algorithm}结果</h3>
            <p>耗时：${data.time.toFixed(4)}秒</p>
            <p>最短距离：${data.distance.toFixed(4)}</p>
        `;
        
        // 高亮显示最近点对
        chart.data.datasets.push({
            label: '最近点对',
            data: data.pair.map(p => ({x: p[0], y: p[1]})),
            backgroundColor: 'rgba(255, 99, 132, 0.8)',
            pointRadius: 6,
            showLine: true,
            borderColor: 'rgba(255, 99, 132, 1)',
            borderWidth: 2
        });
        chart.update();
    };
}

function compareAlgorithms() {
    Promise.all([
        fetch('/api/brute-force', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({points: currentPoints})
        }).then(r => r.json()),
        
        fetch('/api/divide-conquer', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({points: currentPoints})
        }).then(r => r.json())
    ]).then(([bf, dc]) => {
        document.getElementById('timeComparison').innerHTML = `
            <h3>算法对比</h3>
            <p>蛮力法耗时：${bf.time.toFixed(4)}秒</p>
            <p>分治法耗时：${dc.time.toFixed(4)}秒</p>
            <p>性能提升：${((bf.time - dc.time)/bf.time*100).toFixed(1)}%</p>
        `;
    });
}

// 初始生成点
window.onload = generatePoints;