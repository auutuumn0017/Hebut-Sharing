import math
from itertools import combinations
import matplotlib.pyplot as plt
import networkx as nx
from mpl_toolkits.mplot3d import Axes3D
import numpy as np


def tsp_dp(C):
    n = len(C)
    memo = {}  # 存储子问题的解
    all_cities = list(range(n))  # 包含所有城市的列表

    # 预处理：从各个城市直接返回起点0的代价
    for city in range(n):
        if city == 0:  # 起点0不需要处理
            continue
        memo[(city, (0,))] = C[city][0]  # 直接返回起点0的代价

    # 动态规划填表，处理包含0的子集
    def get_prev_subset(subset, next_city):
        return tuple([x for x in subset if x != next_city])

    #subset_size 为子集大小，subset 为当前子集
    for subset_size in range(1, n):  # 子集大小从1到n-1，range生成一个不包含n的整数序列
        for subset in combinations(all_cities, subset_size):# 生成所有子集
            if 0 not in subset:#跳过没有0的子集，因为要从0出发
                continue
            subset = tuple(sorted(subset))  # 确保子集有序

            for current_city in all_cities:
                if current_city in subset:
                    continue  # 当前城市不能在子集中
                # 寻找所有可能的next_city进行状态转移
                min_cost = math.inf

                for next_city in subset:
                    if next_city == 0 and len(subset) > 1:#未遍历完
                        continue 

                    # 前一个子集（移除next_city）
                    prev_subset = get_prev_subset(subset, next_city)
                    prev_key = (next_city, prev_subset)
                    if prev_key in memo:#如果前一个子问题的解已经计算过
                        # 计算当前子问题的解
                        cost = C[current_city][next_city] + memo[prev_key]
                        if cost < min_cost:
                            min_cost = cost
                if min_cost != math.inf:
                    memo[(current_city, subset)] = min_cost

    # 计算最终结果：从0出发，经过所有城市后回到0
    full_subset = tuple(all_cities)
    min_total = math.inf
    for last_city in all_cities[1:]:# 遍历所有城市，排除0
        prev_subset = tuple([x for x in full_subset if x != last_city])# 前一个子集（移除last_city）
        key = (last_city, prev_subset)
        if key in memo:
            cost = C[0][last_city] + memo[key]
            if cost < min_total:
                min_total = cost
    return min_total, memo


def draw_dp_table(memo, n, C, min_total):
    # 生成所有包含0的子集并按长度排序
    subsets = []
    for k in range(n + 1):
        for subset in combinations(range(n), k):
            if 0 in subset:
                subset = tuple(sorted(subset))
                subsets.append(subset)
    subsets = sorted(subsets, key=lambda x: (len(x), x))

    # 构建表格列名
    columns = ['City \\ Subset']
    for subset in subsets:
        subset_str = "{" + ",".join(map(str, subset)) + "}"
        columns.append(subset_str)

    # 填充表格数据
    table_data = []
    full_subset = tuple(range(n))
    for city in range(n):
        row = [f'City {city}']
        for subset in subsets:
            if subset == full_subset:
                # 仅在 City 0 对应的格子填充最小值
                if city == 0:
                    row.append(str(min_total))
                else:
                    row.append('')
            else:
                key = (city, subset)
                value = memo.get(key, '')
                row.append(str(value) if value != '' else '')
        table_data.append(row)

    # 绘制表格
    fig, ax = plt.subplots(figsize=(18, 4))
    ax.axis('tight')
    ax.axis('off')
    table = ax.table(cellText=table_data, colLabels=columns, loc='center', cellLoc='center')
    table.auto_set_font_size(False)
    table.set_fontsize(8)
    plt.title("TSP DP Table")
    plt.show(block=False)


def draw_cost_graph(C):
    # 使用有向图
    G = nx.DiGraph()
    n = len(C)
    if n != 4:
        print("当前城市数量不是 4，无法绘制正四面体。")
        return
    # 添加节点
    G.add_nodes_from(range(n))
    # 添加边和权重
    for i in range(n):
        for j in range(n):
            if i != j and C[i][j] != math.inf:
                G.add_edge(i, j, weight=C[i][j])

    # 正四面体顶点坐标
    pos_3d = {
        0: (0, 0, 0),
        1: (1, 0, 0),
        2: (0.5, np.sqrt(3) / 2, 0),
        3: (0.5, np.sqrt(3) / 6, np.sqrt(6) / 3)
    }

    # 定义四种颜色
    colors = ['r', 'g', 'b', 'y']

    # 创建三维图形
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    # 绘制节点
    for node in G.nodes():
        x, y, z = pos_3d[node]
        # 调整节点大小
        ax.scatter(x, y, z, c='b', s=100)
        # 调整序号文字位置，使其稍微远离节点
        offset = 0.05
        ax.text(x + offset, y + offset, z + offset, str(node), color='red', fontsize=10)

    # 绘制有向边
    for edge in G.edges():
        start = pos_3d[edge[0]]
        end = pos_3d[edge[1]]
        start_node = edge[0]
        # 根据起点选择颜色
        edge_color = colors[start_node % len(colors)]
        ax.plot([start[0], end[0]], [start[1], end[1]], [start[2], end[2]], c=edge_color)

        # 让权值靠近起点
        weight_pos_x = start[0] + 0.2 * (end[0] - start[0])
        weight_pos_y = start[1] + 0.2 * (end[1] - start[1])
        weight_pos_z = start[2] + 0.2 * (end[2] - start[2])
        weight = G[edge[0]][edge[1]]['weight']
        ax.text(weight_pos_x, weight_pos_y, weight_pos_z, str(weight), color='green')

    ax.set_title("3D Cost Graph for TSP")
    plt.show(block=False)


# 示例调用
C = [
    [math.inf, 3, 6, 7],
    [5, math.inf, 2, 3],
    [6, 4, math.inf, 2],
    [3, 7, 5, math.inf]
]

min_cost, memo = tsp_dp(C)
print("最短路径代价:", min_cost)
draw_dp_table(memo, len(C), C, min_cost)  # 传入最短路径代价
draw_cost_graph(C)
plt.show()