import matplotlib.pyplot as plt
from tabulate import tabulate
# 设置matplotlib支持中文的字体
plt.rcParams['font.sans-serif'] = ['SimHei']  # 支持中文

def knapsack(n, weights, values, capacity):
    # 初始化动态规划表格
    dp = [[0]*(capacity+1) for _ in range(n+1)]
    selected = [0]*n
    
    # 创建可视化数据容器
    visual_data = [[" "*(n+2) for _ in range(capacity+1)] for _ in range(n+1)]
    
    # 构建动态规划表
    for i in range(n+1):
        for w in range(capacity+1):
            if i == 0 or w == 0:
                dp[i][w] = 0
                visual_data[i][w] = '0'
            elif weights[i-1] <= w:
                dp[i][w] = max(dp[i-1][w], 
                             dp[i-1][w-weights[i-1]] + values[i-1])
                visual_data[i][w] = f"{dp[i][w]}←" + (
                    "上" if dp[i][w] == dp[i-1][w] 
                    else f"取{i}"
                )
            else:
                dp[i][w] = dp[i-1][w]
                visual_data[i][w] = f"{dp[i][w]}←上"
    
    # 回溯选择过程
    w = capacity
    for i in range(n, 0, -1):
        if dp[i][w] != dp[i-1][w]:
            selected[i-1] = 1
            w -= weights[i-1]
    
    return dp[n][capacity], selected, visual_data

def visualize_table(data, items, capacity):
    # 创建表格头
    headers = ["物品\\容量"] + [str(i) for i in range(capacity+1)]
    
    # 创建表格行
    rows = []
    for i in range(len(data)):
        row = [f"物品{i}" if i>0 else "无物品"] + data[i]
        rows.append(row)
    
    # 使用matplotlib绘制表格
    plt.figure(figsize=(15, 5))
    ax = plt.gca()
    ax.axis('off')
    
    table = ax.table(cellText=rows,
                   colLabels=headers,
                   loc='center',
                   cellLoc='center')
    
    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.scale(1, 1.5)
    plt.title("动态规划过程可视化（箭头表示状态转移方向）")
    plt.show()

def visualize_selection(selected, weights, values):
    # 创建物品展示图
    fig, ax = plt.subplots(figsize=(10, 4))
    
    # 绘制背包
    ax.add_patch(plt.Rectangle((0.1, 0.2), 0.8, 0.6, fill=None, lw=2, edgecolor='black'))
    ax.text(0.5, 0.9, "背包", ha='center', va='center', fontsize=12)
    
    # 绘制物品
    positions = [(0.2 + i*0.15, 0.5) for i in range(len(selected))]
    for i, (s, w, v) in enumerate(zip(selected, weights, values)):
        color = 'green' if s else 'red'
        circle = plt.Circle(positions[i], 0.05, color=color, zorder=2)
        ax.add_patch(circle)
        if s:
            # 给选中物品添加白色边框
            border = plt.Circle(positions[i], 0.05, color='white', fill=False, lw=2, zorder=3)
            ax.add_patch(border)
        ax.text(positions[i][0]-0.02, positions[i][1]-0.1, 
               f"{w}kg\n{v}$", fontsize=8, ha='center', va='center')
    
    # 添加选中物品提示
    selected_items = [i+1 for i, s in enumerate(selected) if s]
    if selected_items:
        ax.text(0.5, 0.1, f"选中物品编号: {', '.join(map(str, selected_items))}", ha='center', va='center', fontsize=10)
    
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis('off')
    plt.title("背包选择结果（绿色为选中物品）")
    plt.show()

if __name__ == "__main__":
    weights = [2, 2, 6, 5, 4]
    values = [6, 3, 5, 4, 6]
    capacity = 10
    
    max_value, selected, visual_data = knapsack(
        len(weights), weights, values, capacity
    )
    
    # 控制台输出
    print("动态规划表格：")
    print(tabulate(visual_data, 
                 headers=[str(i) for i in range(capacity+1)],
                 showindex="always",
                 tablefmt="fancy_grid"))
    
    print(f"\n最大价值：{max_value}")
    print("选中物品：", [i+1 for i, s in enumerate(selected) if s])
    
    # 图形化展示
    visualize_table(visual_data, weights, capacity)
    visualize_selection(selected, weights, values)