import matplotlib.pyplot as plt
import matplotlib.animation as animation
import networkx as nx
import numpy as np

class Item:
    def __init__(self, weight, value):
        self.weight = weight
        self.value = value

def bag_backtracking(items, capacity):
    n = len(items)
    max_value = 0
    best_combination = []  # 记录最优解的物品组合
    G = nx.DiGraph()  # 创建有向图存储搜索树
    node_id = 0
    G.add_node(node_id, label=f"Start\nw: 0\nv: 0")
    frames = []

    def backtrack(index, current_weight, current_value, current_combination, parent_id):
        nonlocal max_value, best_combination, node_id
        
        if index == n:  # 遍历完所有物品
            if current_value > max_value:
                max_value = current_value
                best_combination = current_combination.copy()
            return

        # 记录当前状态，包含物品组合、当前重量、当前价值
        frame = (current_combination.copy(), current_weight, current_value)
        frames.append(frame)

        # 选当前物品（左枝干）
        if current_weight + items[index].weight <= capacity:
            new_node_id = node_id + 1
            # 用 w 和 v 表示重量和价值
            G.add_node(new_node_id, label=f"w: {current_weight + items[index].weight}\nv: {current_value + items[index].value}")
            G.add_edge(parent_id, new_node_id, label='1')  # 标记边为 1 表示选择
            node_id = new_node_id
            current_combination.append(index)  # 选择当前物品
            backtrack(index + 1, current_weight + items[index].weight, current_value + items[index].value, current_combination, new_node_id)
            current_combination.pop()

        # 不选当前物品（右枝干）
        new_node_id = node_id + 1
        # 用 w 和 v 表示重量和价值
        G.add_node(new_node_id, label=f"w: {current_weight}\nv: {current_value}")
        G.add_edge(parent_id, new_node_id, label='0')  # 标记边为 0 表示不选择
        node_id = new_node_id
        backtrack(index + 1, current_weight, current_value, current_combination, new_node_id)  # 不选择当前物品

    backtrack(0, 0, 0, [], 0)

    # 提前计算所有节点的位置
    pos = nx.nx_agraph.graphviz_layout(G, prog='dot')

    node_labels = nx.get_node_attributes(G, 'label')
    edge_labels = nx.get_edge_attributes(G, 'label')

    fig, ax = plt.subplots(figsize=(12, 8))
    # 绘制完整的搜索树，先隐藏节点和边
    nodes = nx.draw_networkx_nodes(G, pos, node_color='lightblue', ax=ax, alpha=0)
    edges = nx.draw_networkx_edges(G, pos, ax=ax, alpha=0)
    nx.draw_networkx_labels(G, pos, labels=node_labels, ax=ax)
    nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels, ax=ax)

    def update(frame):
        current_combination, current_weight, current_value = frame
        ax.clear()
        # 重新绘制完整的搜索树
        nodes = nx.draw_networkx_nodes(G, pos, node_color='lightblue', ax=ax)
        edges = nx.draw_networkx_edges(G, pos, ax=ax)
        nx.draw_networkx_labels(G, pos, labels=node_labels, ax=ax)
        nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels, ax=ax)

        ax.set_title("0 - 1 Bag Backtracking Search Tree")
        # 用 w 和 v 表示重量和价值
        ax.text(0.02, 0.95, f"w: {current_weight}/{capacity}", transform=ax.transAxes)
        ax.text(0.02, 0.90, f"v: {current_value}", transform=ax.transAxes)

        plt.tight_layout()

    ani = animation.FuncAnimation(fig, update, frames=frames, interval=500, repeat=False)
    plt.show()

    return max_value, best_combination

# 定义物品和背包容量
weights = [2, 2, 6, 5, 4]
values = [6, 3, 5, 4, 6]
capacity = 10

# 创建物品对象
items = [Item(w, v) for w, v in zip(weights, values)]

# 调用回溯法求解
max_value, best_combination = bag_backtracking(items, capacity)

# 输出结果
print("最大价值:", max_value)
print("最优组合（物品索引）:", best_combination)