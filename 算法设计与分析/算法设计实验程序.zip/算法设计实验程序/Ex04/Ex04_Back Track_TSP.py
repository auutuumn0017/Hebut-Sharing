import matplotlib.pyplot as plt
import matplotlib.animation as animation
import networkx as nx


def tsp_backtracking(C, n, current_city, path, min_cost, best_path, G, node_id, parent_id, frames):
    if len(path) == n:
        # 计算回到起点的距离
        if path:  # 确保 path 不为空
            return_cost = C[path[-1]][0]
            total_cost = return_cost + sum(C[path[i - 1]][path[i]] for i in range(1, n))
            if total_cost < min_cost[0]:
                min_cost[0] = total_cost
                best_path[0] = path + [0]
            # 记录当前状态
            frames.append((G.copy(), path.copy(), total_cost))
        return node_id

    # 计算当前路径的代价-
    current_cost = sum(C[path[i - 1]][path[i]] for i in range(1, len(path)))
    # 剪枝：如果当前代价已经超过已知最小代价，停止搜索该分支
    if current_cost >= min_cost[0]:
        return node_id

    new_node_id = node_id
    for next_city in range(n):  # 修正遍历范围
        if next_city not in path:
            new_node_id += 1
            # 计算添加下一个城市后的当前代价
            next_cost = current_cost + C[path[-1]][next_city] if path else 0
            G.add_node(new_node_id, label=f"City: {next_city}\nCost: {next_cost}")
            G.add_edge(parent_id, new_node_id, label=f"{next_city}")
            path.append(next_city)
            new_node_id = tsp_backtracking(C, n, next_city, path, min_cost, best_path, G, new_node_id, new_node_id, frames)
            path.pop()
            # 记录当前状态
            if path:  # 确保 path 不为空
                frames.append((G.copy(), path.copy(), sum(C[path[i - 1]][path[i]] for i in range(1, len(path)))))
    return new_node_id
 

def solve_tsp(C):
    n = len(C)
    min_cost = [float('inf')]  # 存储最小代价
    best_path = [[]]  # 存储最佳路径
    G = nx.DiGraph()
    G.add_node(0, label=f"City: 0\nCost: 0")
    node_id = 0
    frames = []
    tsp_backtracking(C, n, 0, [0], min_cost, best_path, G, node_id, 0, frames)

    # 提前计算所有节点的位置
    pos = nx.nx_agraph.graphviz_layout(G, prog='dot')

    node_labels = nx.get_node_attributes(G, 'label')
    edge_labels = nx.get_edge_attributes(G, 'label')

    fig, ax = plt.subplots(figsize=(12, 8))

    def update(frame):
        G, path, cost = frame
        ax.clear()
        # 重新绘制完整的搜索树
        nodes = nx.draw_networkx_nodes(G, pos, node_color='lightblue', ax=ax)
        edges = nx.draw_networkx_edges(G, pos, ax=ax)
        nx.draw_networkx_labels(G, pos, labels=node_labels, ax=ax)
        nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels, ax=ax)

        ax.set_title("TSP Backtracking Search Tree")
        ax.text(0.02, 0.95, f"Current Path: {path}", transform=ax.transAxes)
        ax.text(0.02, 0.90, f"Current Cost: {cost}", transform=ax.transAxes)

        plt.tight_layout()

    ani = animation.FuncAnimation(fig, update, frames=frames, interval=500, repeat=False)
    plt.show()

    return min_cost[0], best_path[0]


# 代价矩阵
C = [
    [float('inf'), 3, 6, 7],
    [5, float('inf'), 2, 3],
    [6, 4, float('inf'), 2],
    [3, 7, 5, float('inf')]
]

# 求解TSP问题
min_cost, best_path = solve_tsp(C)

# 输出结果
print("最小代价:", min_cost)
print("最佳路径:", best_path)