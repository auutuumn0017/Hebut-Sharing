import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

# 给定的距离矩阵
C = np.array([
    [np.inf, 3, 3, 2, 6],
    [3, np.inf, 7, 3, 2],
    [3, 7, np.inf, 2, 5],
    [2, 3, 2, np.inf, 3],
    [6, 2, 5, 3, np.inf]
])

# 城市坐标（假设出来的）
coords = np.array([
    [0, 0],
    [1, 5],
    [2, 2],
    [4, 1],
    [3, 4]
])

def nearest_neighbor_tsp(C, coords, start_city):
    n = len(C)
    visited = [False] * n
    path = [start_city]  # 从指定城市开始
    visited[start_city] = True
    current_city = start_city

    while len(path) < n:
        last_city = path[-1]
        next_city = None
        min_dist = np.inf

        for i in range(n):
            if not visited[i] and C[last_city][i] < min_dist:
                min_dist = C[last_city][i]
                next_city = i

        path.append(next_city)
        visited[next_city] = True
        current_city = next_city

    path.append(start_city)  # 返回起始城市
    return path

def calculate_path_length(C, path):
    length = 0
    for i in range(len(path) - 1):
        length += C[path[i]][path[i + 1]]
    return length

# 创建一个 2x3 的子图布局
fig, axes = plt.subplots(2, 3, figsize=(15, 10))
axes = axes.flatten()

# 计算从每个城市出发的路径并绘图
for start_city in range(len(C)):
    path = nearest_neighbor_tsp(C, coords, start_city)
    path_length = calculate_path_length(C, path)
    path = np.array(path)
    coords_path = coords[path]

    ax = axes[start_city]
    ax.plot(coords_path[:, 0], coords_path[:, 1], 'o-')
    ax.plot([coords_path[0, 0], coords_path[-1, 0]], [coords_path[0, 1], coords_path[-1, 1]], 'k-')
    # 路径长度取整显示
    ax.set_title(f"Start from City {start_city}, Length: {int(path_length)}")
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.grid(True)

    # 标注起始点序号
    start_coord = coords[start_city]
    ax.text(start_coord[0], start_coord[1], str(start_city), color='red', fontsize=12, ha='center', va='center')

    # 在每段路径上标注长度，取整显示
    for i in range(len(path) - 1):
        city1 = path[i]
        city2 = path[i + 1]
        dist = C[city1][city2]
        x_mid = (coords[city1][0] + coords[city2][0]) / 2
        y_mid = (coords[city1][1] + coords[city2][1]) / 2
        ax.text(x_mid, y_mid, f"{int(dist)}", color='blue', fontsize=10, ha='center', va='center')
    
    # 设置横轴刻度为整数
    ax.xaxis.set_major_locator(MaxNLocator(integer=True))

# 第六张图显示最初点与点之间的路径
ax = axes[-1]
for i in range(len(coords)):
    for j in range(i + 1, len(coords)):
        ax.plot([coords[i][0], coords[j][0]], [coords[i][1], coords[j][1]], 'b-', alpha=0.3)
        dist = C[i][j]
        x_mid = (coords[i][0] + coords[j][0]) / 2
        y_mid = (coords[i][1] + coords[j][1]) / 2
        # 标注长度取整显示
        ax.text(x_mid, y_mid, f"{int(dist)}", color='blue', fontsize=10, ha='center', va='center')

# 标注城市序号
for i, coord in enumerate(coords):
    ax.text(coord[0], coord[1], str(i), color='red', fontsize=12, ha='center', va='center')

# 修改最后一个子图的标题，去掉总长度信息
ax.set_title("Initial Point - Point Paths")
ax.set_xlabel("X")
ax.set_ylabel("Y")
ax.grid(True)
# 设置最后一个子图横轴刻度为整数
ax.xaxis.set_major_locator(MaxNLocator(integer=True))

plt.tight_layout()
plt.show()